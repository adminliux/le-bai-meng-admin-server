/*     */ package org.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONArray
/*     */ {
/*     */   private final ArrayList myArrayList;
/*     */   
/*  91 */   public JSONArray() { this.myArrayList = new ArrayList(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(JSONTokener x) throws JSONException {
/* 103 */     this();
/* 104 */     if (x.nextClean() != '[') {
/* 105 */       throw x.syntaxError("A JSONArray text must start with '['");
/*     */     }
/* 107 */     if (x.nextClean() != ']') {
/* 108 */       x.back();
/*     */       while (true) {
/* 110 */         if (x.nextClean() == ',') {
/* 111 */           x.back();
/* 112 */           this.myArrayList.add(JSONObject.NULL);
/*     */         } else {
/* 114 */           x.back();
/* 115 */           this.myArrayList.add(x.nextValue());
/*     */         } 
/* 117 */         switch (x.nextClean()) {
/*     */           case ',':
/* 119 */             if (x.nextClean() == ']') {
/*     */               return;
/*     */             }
/* 122 */             x.back(); break;
/*     */           case ']':
/*     */             return;
/*     */         } 
/*     */       } 
/* 127 */       throw x.syntaxError("Expected a ',' or ']'");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public JSONArray(String source) throws JSONException { this(new JSONTokener(source)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(Collection collection) {
/* 154 */     this.myArrayList = new ArrayList();
/* 155 */     if (collection != null) {
/* 156 */       Iterator iter = collection.iterator();
/* 157 */       while (iter.hasNext()) {
/* 158 */         this.myArrayList.add(JSONObject.wrap(iter.next()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray(Object array) throws JSONException {
/* 170 */     this();
/* 171 */     if (array.getClass().isArray()) {
/* 172 */       int length = Array.getLength(array);
/* 173 */       for (int i = 0; i < length; i++) {
/* 174 */         put(JSONObject.wrap(Array.get(array, i)));
/*     */       }
/*     */     } else {
/* 177 */       throw new JSONException(
/* 178 */           "JSONArray initial value should be a string or collection or array.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int index) throws JSONException {
/* 192 */     Object object = opt(index);
/* 193 */     if (object == null) {
/* 194 */       throw new JSONException("JSONArray[" + index + "] not found.");
/*     */     }
/* 196 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int index) throws JSONException {
/* 211 */     Object object = get(index);
/* 212 */     if (object.equals(Boolean.FALSE) || (
/* 213 */       object instanceof String && ((String)object)
/* 214 */       .equalsIgnoreCase("false")))
/* 215 */       return false; 
/* 216 */     if (object.equals(Boolean.TRUE) || (
/* 217 */       object instanceof String && ((String)object)
/* 218 */       .equalsIgnoreCase("true"))) {
/* 219 */       return true;
/*     */     }
/* 221 */     throw new JSONException("JSONArray[" + index + "] is not a boolean.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDouble(int index) throws JSONException {
/* 235 */     Object object = get(index);
/*     */     try {
/* 237 */       return (object instanceof Number) ? ((Number)object).doubleValue() : 
/* 238 */         Double.parseDouble((String)object);
/* 239 */     } catch (Exception e) {
/* 240 */       throw new JSONException("JSONArray[" + index + "] is not a number.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt(int index) throws JSONException {
/* 254 */     Object object = get(index);
/*     */     try {
/* 256 */       return (object instanceof Number) ? ((Number)object).intValue() : 
/* 257 */         Integer.parseInt((String)object);
/* 258 */     } catch (Exception e) {
/* 259 */       throw new JSONException("JSONArray[" + index + "] is not a number.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray getJSONArray(int index) throws JSONException {
/* 274 */     Object object = get(index);
/* 275 */     if (object instanceof JSONArray) {
/* 276 */       return (JSONArray)object;
/*     */     }
/* 278 */     throw new JSONException("JSONArray[" + index + "] is not a JSONArray.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject getJSONObject(int index) throws JSONException {
/* 292 */     Object object = get(index);
/* 293 */     if (object instanceof JSONObject) {
/* 294 */       return (JSONObject)object;
/*     */     }
/* 296 */     throw new JSONException("JSONArray[" + index + "] is not a JSONObject.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong(int index) throws JSONException {
/* 310 */     Object object = get(index);
/*     */     try {
/* 312 */       return (object instanceof Number) ? ((Number)object).longValue() : 
/* 313 */         Long.parseLong((String)object);
/* 314 */     } catch (Exception e) {
/* 315 */       throw new JSONException("JSONArray[" + index + "] is not a number.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(int index) throws JSONException {
/* 329 */     Object object = get(index);
/* 330 */     if (object instanceof String) {
/* 331 */       return (String)object;
/*     */     }
/* 333 */     throw new JSONException("JSONArray[" + index + "] not a string.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 344 */   public boolean isNull(int index) throws JSONException { return JSONObject.NULL.equals(opt(index)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String join(String separator) throws JSONException {
/* 359 */     int len = length();
/* 360 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 362 */     for (int i = 0; i < len; i++) {
/* 363 */       if (i > 0) {
/* 364 */         sb.append(separator);
/*     */       }
/* 366 */       sb.append(JSONObject.valueToString(this.myArrayList.get(i)));
/*     */     } 
/* 368 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 377 */   public int length() { return this.myArrayList.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object opt(int index) throws JSONException {
/* 388 */     return (index < 0 || index >= length()) ? null : this.myArrayList
/* 389 */       .get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 402 */   public boolean optBoolean(int index) throws JSONException { return optBoolean(index, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean optBoolean(int index, boolean defaultValue) {
/*     */     try {
/* 418 */       return getBoolean(index);
/* 419 */     } catch (Exception e) {
/* 420 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 434 */   public double optDouble(int index) throws JSONException { return optDouble(index, NaND); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double optDouble(int index, double defaultValue) {
/*     */     try {
/* 450 */       return getDouble(index);
/* 451 */     } catch (Exception e) {
/* 452 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 466 */   public int optInt(int index) throws JSONException { return optInt(index, 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int optInt(int index, int defaultValue) {
/*     */     try {
/* 482 */       return getInt(index);
/* 483 */     } catch (Exception e) {
/* 484 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray optJSONArray(int index) throws JSONException {
/* 497 */     Object o = opt(index);
/* 498 */     return (o instanceof JSONArray) ? (JSONArray)o : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject optJSONObject(int index) throws JSONException {
/* 511 */     Object o = opt(index);
/* 512 */     return (o instanceof JSONObject) ? (JSONObject)o : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 525 */   public long optLong(int index) throws JSONException { return optLong(index, 0L); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long optLong(int index, long defaultValue) {
/*     */     try {
/* 541 */       return getLong(index);
/* 542 */     } catch (Exception e) {
/* 543 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 557 */   public String optString(int index) throws JSONException { return optString(index, ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String optString(int index, String defaultValue) {
/* 571 */     Object object = opt(index);
/* 572 */     return JSONObject.NULL.equals(object) ? defaultValue : object
/* 573 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(boolean value) {
/* 584 */     put(value ? Boolean.TRUE : Boolean.FALSE);
/* 585 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(Collection value) {
/* 597 */     put(new JSONArray(value));
/* 598 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(double value) throws JSONException {
/* 611 */     Double d = new Double(value);
/* 612 */     JSONObject.testValidity(d);
/* 613 */     put(d);
/* 614 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int value) throws JSONException {
/* 625 */     put(new Integer(value));
/* 626 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(long value) {
/* 637 */     put(new Long(value));
/* 638 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(Map value) {
/* 650 */     put(new JSONObject(value));
/* 651 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(Object value) {
/* 664 */     this.myArrayList.add(value);
/* 665 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, boolean value) throws JSONException {
/* 682 */     put(index, value ? Boolean.TRUE : Boolean.FALSE);
/* 683 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, Collection value) throws JSONException {
/* 699 */     put(index, new JSONArray(value));
/* 700 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, double value) throws JSONException {
/* 717 */     put(index, new Double(value));
/* 718 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, int value) throws JSONException {
/* 735 */     put(index, new Integer(value));
/* 736 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, long value) throws JSONException {
/* 753 */     put(index, new Long(value));
/* 754 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, Map value) throws JSONException {
/* 771 */     put(index, new JSONObject(value));
/* 772 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONArray put(int index, Object value) throws JSONException {
/* 792 */     JSONObject.testValidity(value);
/* 793 */     if (index < 0) {
/* 794 */       throw new JSONException("JSONArray[" + index + "] not found.");
/*     */     }
/* 796 */     if (index < length()) {
/* 797 */       this.myArrayList.set(index, value);
/*     */     } else {
/* 799 */       while (index != length()) {
/* 800 */         put(JSONObject.NULL);
/*     */       }
/* 802 */       put(value);
/*     */     } 
/* 804 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(int index) throws JSONException {
/* 816 */     Object o = opt(index);
/* 817 */     if (index >= 0 && index < length()) {
/* 818 */       this.myArrayList.remove(index);
/*     */     }
/* 820 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONObject toJSONObject(JSONArray names) throws JSONException {
/* 836 */     if (names == null || names.length() == 0 || length() == 0) {
/* 837 */       return null;
/*     */     }
/* 839 */     JSONObject jo = new JSONObject();
/* 840 */     for (int i = 0; i < names.length(); i++) {
/* 841 */       jo.put(names.getString(i), opt(i));
/*     */     }
/* 843 */     return jo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     try {
/* 859 */       return toString(0);
/* 860 */     } catch (Exception e) {
/* 861 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(int indentFactor) throws JSONException {
/* 878 */     StringWriter sw = new StringWriter();
/* 879 */     synchronized (sw.getBuffer()) {
/* 880 */       return write(sw, indentFactor, 0).toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 894 */   public Writer write(Writer writer) throws JSONException { return write(writer, 0, 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Writer write(Writer writer, int indentFactor, int indent) throws JSONException {
/*     */     try {
/* 913 */       boolean commanate = false;
/* 914 */       int length = length();
/* 915 */       writer.write(91);
/*     */       
/* 917 */       if (length == 1) {
/* 918 */         JSONObject.writeValue(writer, this.myArrayList.get(0), 
/* 919 */             indentFactor, indent);
/* 920 */       } else if (length != 0) {
/* 921 */         int newindent = indent + indentFactor;
/*     */         
/* 923 */         for (int i = 0; i < length; i++) {
/* 924 */           if (commanate) {
/* 925 */             writer.write(44);
/*     */           }
/* 927 */           if (indentFactor > 0) {
/* 928 */             writer.write(10);
/*     */           }
/* 930 */           JSONObject.indent(writer, newindent);
/* 931 */           JSONObject.writeValue(writer, this.myArrayList.get(i), 
/* 932 */               indentFactor, newindent);
/* 933 */           commanate = true;
/*     */         } 
/* 935 */         if (indentFactor > 0) {
/* 936 */           writer.write(10);
/*     */         }
/* 938 */         JSONObject.indent(writer, indent);
/*     */       } 
/* 940 */       writer.write(93);
/* 941 */       return writer;
/* 942 */     } catch (IOException e) {
/* 943 */       throw new JSONException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/json.jar!/org/json/JSONArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */