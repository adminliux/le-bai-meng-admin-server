/*    */ package org.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSONException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 0L;
/*    */   private Throwable cause;
/*    */   
/* 20 */   public JSONException(String message) { super(message); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JSONException(Throwable cause) {
/* 27 */     super(cause.getMessage());
/* 28 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   public Throwable getCause() { return this.cause; }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/json.jar!/org/json/JSONException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */