package org.apache.commons.fileupload.util;

import java.io.IOException;

public interface Closeable {
  void close() throws IOException;
  
  boolean isClosed() throws IOException;
}


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/util/Closeable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */