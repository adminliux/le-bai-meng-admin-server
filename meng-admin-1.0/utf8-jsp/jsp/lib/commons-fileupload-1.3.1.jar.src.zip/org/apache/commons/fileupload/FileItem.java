package org.apache.commons.fileupload;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;

public interface FileItem extends Serializable, FileItemHeadersSupport {
  InputStream getInputStream() throws IOException;
  
  String getContentType();
  
  String getName();
  
  boolean isInMemory();
  
  long getSize();
  
  byte[] get();
  
  String getString(String paramString) throws UnsupportedEncodingException;
  
  String getString();
  
  void write(File paramFile) throws Exception;
  
  void delete();
  
  String getFieldName();
  
  void setFieldName(String paramString);
  
  boolean isFormField();
  
  void setFormField(boolean paramBoolean);
  
  OutputStream getOutputStream() throws IOException;
}


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/FileItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */