/*      */ package org.apache.commons.fileupload;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import org.apache.commons.fileupload.util.Closeable;
/*      */ import org.apache.commons.fileupload.util.Streams;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MultipartStream
/*      */ {
/*      */   public static final byte CR = 13;
/*      */   public static final byte LF = 10;
/*      */   public static final byte DASH = 45;
/*      */   public static final int HEADER_PART_SIZE_MAX = 10240;
/*      */   protected static final int DEFAULT_BUFSIZE = 4096;
/*      */   
/*      */   public static class ProgressNotifier
/*      */   {
/*      */     private final ProgressListener listener;
/*      */     private final long contentLength;
/*      */     private long bytesRead;
/*      */     private int items;
/*      */     
/*      */     ProgressNotifier(ProgressListener pListener, long pContentLength) {
/*  122 */       this.listener = pListener;
/*  123 */       this.contentLength = pContentLength;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void noteBytesRead(int pBytes) {
/*  135 */       this.bytesRead += pBytes;
/*  136 */       notifyListener();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void noteItem() {
/*  143 */       this.items++;
/*  144 */       notifyListener();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void notifyListener() {
/*  151 */       if (this.listener != null) {
/*  152 */         this.listener.update(this.bytesRead, this.contentLength, this.items);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   protected static final byte[] HEADER_SEPARATOR = { 13, 10, 13, 10 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  196 */   protected static final byte[] FIELD_SEPARATOR = { 13, 10 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   protected static final byte[] STREAM_TERMINATOR = { 45, 45 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  207 */   protected static final byte[] BOUNDARY_PREFIX = { 13, 10, 45, 45 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final InputStream input;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int boundaryLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int keepRegion;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] boundary;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int bufSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final byte[] buffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int head;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int tail;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String headerEncoding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ProgressNotifier notifier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*  276 */   public MultipartStream() { this(null, null, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*  298 */   public MultipartStream(InputStream input, byte[] boundary, int bufSize) { this(input, boundary, bufSize, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MultipartStream(InputStream input, byte[] boundary, int bufSize, ProgressNotifier pNotifier) {
/*  325 */     if (boundary == null) {
/*  326 */       throw new IllegalArgumentException("boundary may not be null");
/*      */     }
/*      */     
/*  329 */     this.input = input;
/*  330 */     this.bufSize = bufSize;
/*  331 */     this.buffer = new byte[bufSize];
/*  332 */     this.notifier = pNotifier;
/*      */ 
/*      */ 
/*      */     
/*  336 */     this.boundaryLength = boundary.length + BOUNDARY_PREFIX.length;
/*  337 */     if (bufSize < this.boundaryLength + 1) {
/*  338 */       throw new IllegalArgumentException("The buffer size specified for the MultipartStream is too small");
/*      */     }
/*      */     
/*  341 */     this.boundary = new byte[this.boundaryLength];
/*  342 */     this.keepRegion = this.boundary.length;
/*      */     
/*  344 */     System.arraycopy(BOUNDARY_PREFIX, 0, this.boundary, 0, BOUNDARY_PREFIX.length);
/*      */     
/*  346 */     System.arraycopy(boundary, 0, this.boundary, BOUNDARY_PREFIX.length, boundary.length);
/*      */ 
/*      */     
/*  349 */     this.head = 0;
/*  350 */     this.tail = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  367 */   MultipartStream(InputStream input, byte[] boundary, ProgressNotifier pNotifier) { this(input, boundary, 4096, pNotifier); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*  383 */   public MultipartStream(InputStream input, byte[] boundary) { this(input, boundary, 4096, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  396 */   public String getHeaderEncoding() { return this.headerEncoding; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  407 */   public void setHeaderEncoding(String encoding) { this.headerEncoding = encoding; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte readByte() throws IOException {
/*  420 */     if (this.head == this.tail) {
/*  421 */       this.head = 0;
/*      */       
/*  423 */       this.tail = this.input.read(this.buffer, this.head, this.bufSize);
/*  424 */       if (this.tail == -1)
/*      */       {
/*  426 */         throw new IOException("No more data is available");
/*      */       }
/*  428 */       if (this.notifier != null) {
/*  429 */         this.notifier.noteBytesRead(this.tail);
/*      */       }
/*      */     } 
/*  432 */     return this.buffer[this.head++];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readBoundary() throws FileUploadBase.FileUploadIOException, MalformedStreamException {
/*  448 */     byte[] marker = new byte[2];
/*  449 */     boolean nextChunk = false;
/*      */     
/*  451 */     this.head += this.boundaryLength;
/*      */     try {
/*  453 */       marker[0] = readByte();
/*  454 */       if (marker[0] == 10)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  461 */         return true;
/*      */       }
/*      */       
/*  464 */       marker[1] = readByte();
/*  465 */       if (arrayequals(marker, STREAM_TERMINATOR, 2)) {
/*  466 */         nextChunk = false;
/*  467 */       } else if (arrayequals(marker, FIELD_SEPARATOR, 2)) {
/*  468 */         nextChunk = true;
/*      */       } else {
/*  470 */         throw new MalformedStreamException("Unexpected characters follow a boundary");
/*      */       }
/*      */     
/*  473 */     } catch (FileUploadIOException e) {
/*      */       
/*  475 */       throw e;
/*  476 */     } catch (IOException e) {
/*  477 */       throw new MalformedStreamException("Stream ended unexpectedly");
/*      */     } 
/*  479 */     return nextChunk;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoundary(byte[] boundary) throws IllegalBoundaryException {
/*  503 */     if (boundary.length != this.boundaryLength - BOUNDARY_PREFIX.length) {
/*  504 */       throw new IllegalBoundaryException("The length of a boundary token can not be changed");
/*      */     }
/*      */     
/*  507 */     System.arraycopy(boundary, 0, this.boundary, BOUNDARY_PREFIX.length, boundary.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String readHeaders() {
/*  528 */     int i = 0;
/*      */ 
/*      */     
/*  531 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  532 */     int size = 0;
/*  533 */     while (i < HEADER_SEPARATOR.length) {
/*      */       byte b; try {
/*  535 */         b = readByte();
/*  536 */       } catch (FileUploadIOException e) {
/*      */         
/*  538 */         throw e;
/*  539 */       } catch (IOException e) {
/*  540 */         throw new MalformedStreamException("Stream ended unexpectedly");
/*      */       } 
/*  542 */       if (++size > 10240) {
/*  543 */         throw new MalformedStreamException(String.format("Header section has more than %s bytes (maybe it is not properly terminated)", new Object[] { Integer.valueOf(10240) }));
/*      */       }
/*      */ 
/*      */       
/*  547 */       if (b == HEADER_SEPARATOR[i]) {
/*  548 */         i++;
/*      */       } else {
/*  550 */         i = 0;
/*      */       } 
/*  552 */       baos.write(b);
/*      */     } 
/*      */     
/*  555 */     String headers = null;
/*  556 */     if (this.headerEncoding != null) {
/*      */       try {
/*  558 */         headers = baos.toString(this.headerEncoding);
/*  559 */       } catch (UnsupportedEncodingException e) {
/*      */ 
/*      */         
/*  562 */         headers = baos.toString();
/*      */       } 
/*      */     } else {
/*  565 */       headers = baos.toString();
/*      */     } 
/*      */     
/*  568 */     return headers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBodyData(OutputStream output) throws MalformedStreamException, IOException {
/*  592 */     InputStream istream = newInputStream();
/*  593 */     return (int)Streams.copy(istream, output, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  601 */   ItemInputStream newInputStream() { return new ItemInputStream(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  617 */   public int discardBodyData() throws MalformedStreamException, IOException { return readBodyData(null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean skipPreamble() throws FileUploadBase.FileUploadIOException, MalformedStreamException {
/*  630 */     System.arraycopy(this.boundary, 2, this.boundary, 0, this.boundary.length - 2);
/*  631 */     this.boundaryLength = this.boundary.length - 2;
/*      */     
/*      */     try {
/*  634 */       discardBodyData();
/*      */ 
/*      */ 
/*      */       
/*  638 */       return readBoundary();
/*  639 */     } catch (MalformedStreamException e) {
/*  640 */       return false;
/*      */     } finally {
/*      */       
/*  643 */       System.arraycopy(this.boundary, 0, this.boundary, 2, this.boundary.length - 2);
/*  644 */       this.boundaryLength = this.boundary.length;
/*  645 */       this.boundary[0] = 13;
/*  646 */       this.boundary[1] = 10;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean arrayequals(byte[] a, byte[] b, int count) {
/*  664 */     for (int i = 0; i < count; i++) {
/*  665 */       if (a[i] != b[i]) {
/*  666 */         return false;
/*      */       }
/*      */     } 
/*  669 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int findByte(byte value, int pos) {
/*  684 */     for (int i = pos; i < this.tail; i++) {
/*  685 */       if (this.buffer[i] == value) {
/*  686 */         return i;
/*      */       }
/*      */     } 
/*      */     
/*  690 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int findSeparator() throws MalformedStreamException, IOException {
/*  703 */     int match = 0;
/*  704 */     int maxpos = this.tail - this.boundaryLength; int first;
/*  705 */     for (first = this.head; first <= maxpos && match != this.boundaryLength; first++) {
/*  706 */       first = findByte(this.boundary[0], first);
/*  707 */       if (first == -1 || first > maxpos) {
/*  708 */         return -1;
/*      */       }
/*  710 */       for (match = 1; match < this.boundaryLength && 
/*  711 */         this.buffer[first + match] == this.boundary[match]; match++);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  716 */     if (match == this.boundaryLength) {
/*  717 */       return first - 1;
/*      */     }
/*  719 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class MalformedStreamException
/*      */     extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = 6466926458059796677L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MalformedStreamException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  748 */     public MalformedStreamException(String message) { super(message); }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IllegalBoundaryException
/*      */     extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = -161533165102632918L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IllegalBoundaryException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  778 */     public IllegalBoundaryException(String message) { super(message); }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public class ItemInputStream
/*      */     extends InputStream
/*      */     implements Closeable
/*      */   {
/*      */     private long total;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int pad;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int pos;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean closed;
/*      */ 
/*      */ 
/*      */     
/*      */     private static final int BYTE_POSITIVE_OFFSET = 256;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  813 */     ItemInputStream() { findSeparator(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void findSeparator() {
/*  820 */       this.pos = MultipartStream.this.findSeparator();
/*  821 */       if (this.pos == -1) {
/*  822 */         if (MultipartStream.this.tail - MultipartStream.this.head > MultipartStream.this.keepRegion) {
/*  823 */           this.pad = MultipartStream.this.keepRegion;
/*      */         } else {
/*  825 */           this.pad = MultipartStream.this.tail - MultipartStream.this.head;
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  837 */     public long getBytesRead() { return this.total; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int available() throws MultipartStream.MalformedStreamException, IOException {
/*  849 */       if (this.pos == -1) {
/*  850 */         return MultipartStream.this.tail - MultipartStream.this.head - this.pad;
/*      */       }
/*  852 */       return this.pos - MultipartStream.this.head;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int read() throws MultipartStream.MalformedStreamException, IOException {
/*  869 */       if (this.closed) {
/*  870 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  872 */       if (available() == 0 && makeAvailable() == 0) {
/*  873 */         return -1;
/*      */       }
/*  875 */       this.total++;
/*  876 */       int b = MultipartStream.this.buffer[MultipartStream.this.head++];
/*  877 */       if (b >= 0) {
/*  878 */         return b;
/*      */       }
/*  880 */       return b + 256;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int read(byte[] b, int off, int len) throws IOException {
/*  895 */       if (this.closed) {
/*  896 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  898 */       if (len == 0) {
/*  899 */         return 0;
/*      */       }
/*  901 */       int res = available();
/*  902 */       if (res == 0) {
/*  903 */         res = makeAvailable();
/*  904 */         if (res == 0) {
/*  905 */           return -1;
/*      */         }
/*      */       } 
/*  908 */       res = Math.min(res, len);
/*  909 */       System.arraycopy(MultipartStream.this.buffer, MultipartStream.this.head, b, off, res);
/*  910 */       MultipartStream.this.head += res;
/*  911 */       this.total += res;
/*  912 */       return res;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  922 */     public void close() { close(false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close(boolean pCloseUnderlying) throws IOException {
/*  933 */       if (this.closed) {
/*      */         return;
/*      */       }
/*  936 */       if (pCloseUnderlying) {
/*  937 */         this.closed = true;
/*  938 */         MultipartStream.this.input.close();
/*      */       } else {
/*      */         while (true) {
/*  941 */           int av = available();
/*  942 */           if (av == 0) {
/*  943 */             av = makeAvailable();
/*  944 */             if (av == 0) {
/*      */               break;
/*      */             }
/*      */           } 
/*  948 */           skip(av);
/*      */         } 
/*      */       } 
/*  951 */       this.closed = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long skip(long bytes) throws IOException {
/*  964 */       if (this.closed) {
/*  965 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  967 */       int av = available();
/*  968 */       if (av == 0) {
/*  969 */         av = makeAvailable();
/*  970 */         if (av == 0) {
/*  971 */           return 0L;
/*      */         }
/*      */       } 
/*  974 */       long res = Math.min(av, bytes);
/*  975 */       MultipartStream.access$114(MultipartStream.this, res);
/*  976 */       return res;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int makeAvailable() throws MultipartStream.MalformedStreamException, IOException {
/*      */       int av;
/*  986 */       if (this.pos != -1) {
/*  987 */         return 0;
/*      */       }
/*      */ 
/*      */       
/*  991 */       this.total += (MultipartStream.this.tail - MultipartStream.this.head - this.pad);
/*  992 */       System.arraycopy(MultipartStream.this.buffer, MultipartStream.this.tail - this.pad, MultipartStream.this.buffer, 0, this.pad);
/*      */ 
/*      */       
/*  995 */       MultipartStream.this.head = 0;
/*  996 */       MultipartStream.this.tail = this.pad;
/*      */       
/*      */       do {
/*  999 */         int bytesRead = MultipartStream.this.input.read(MultipartStream.this.buffer, MultipartStream.this.tail, MultipartStream.this.bufSize - MultipartStream.this.tail);
/* 1000 */         if (bytesRead == -1) {
/*      */ 
/*      */ 
/*      */           
/* 1004 */           String msg = "Stream ended unexpectedly";
/* 1005 */           throw new MultipartStream.MalformedStreamException("Stream ended unexpectedly");
/*      */         } 
/* 1007 */         if (MultipartStream.this.notifier != null) {
/* 1008 */           MultipartStream.this.notifier.noteBytesRead(bytesRead);
/*      */         }
/* 1010 */         MultipartStream.this.tail += bytesRead;
/*      */         
/* 1012 */         findSeparator();
/* 1013 */         av = available();
/*      */       }
/* 1015 */       while (av <= 0 && this.pos == -1);
/* 1016 */       return av;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1027 */     public boolean isClosed() throws FileUploadBase.FileUploadIOException, MultipartStream.MalformedStreamException { return this.closed; }
/*      */   }
/*      */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/MultipartStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */