/*    */ package org.apache.commons.fileupload.servlet;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.commons.io.FileCleaningTracker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileCleanerCleanup
/*    */   implements ServletContextListener
/*    */ {
/* 38 */   public static final String FILE_CLEANING_TRACKER_ATTRIBUTE = FileCleanerCleanup.class.getName() + ".FileCleaningTracker";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public static FileCleaningTracker getFileCleaningTracker(ServletContext pServletContext) { return (FileCleaningTracker)pServletContext.getAttribute(FILE_CLEANING_TRACKER_ATTRIBUTE); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   public static void setFileCleaningTracker(ServletContext pServletContext, FileCleaningTracker pTracker) { pServletContext.setAttribute(FILE_CLEANING_TRACKER_ATTRIBUTE, pTracker); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public void contextInitialized(ServletContextEvent sce) { setFileCleaningTracker(sce.getServletContext(), new FileCleaningTracker()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 86 */   public void contextDestroyed(ServletContextEvent sce) { getFileCleaningTracker(sce.getServletContext()).exitWhenFinished(); }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/servlet/FileCleanerCleanup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */