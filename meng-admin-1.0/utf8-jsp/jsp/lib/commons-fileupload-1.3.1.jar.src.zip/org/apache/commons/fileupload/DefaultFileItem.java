/*    */ package org.apache.commons.fileupload;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.apache.commons.fileupload.disk.DiskFileItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class DefaultFileItem
/*    */   extends DiskFileItem
/*    */ {
/*    */   private static final long serialVersionUID = 4088572813833518255L;
/*    */   
/*    */   @Deprecated
/* 73 */   public DefaultFileItem(String fieldName, String contentType, boolean isFormField, String fileName, int sizeThreshold, File repository) { super(fieldName, contentType, isFormField, fileName, sizeThreshold, repository); }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/DefaultFileItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */