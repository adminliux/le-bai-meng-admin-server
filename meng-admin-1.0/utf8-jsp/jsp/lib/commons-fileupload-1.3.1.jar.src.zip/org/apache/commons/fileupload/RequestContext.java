package org.apache.commons.fileupload;

import java.io.IOException;
import java.io.InputStream;

public interface RequestContext {
  String getCharacterEncoding();
  
  String getContentType();
  
  @Deprecated
  int getContentLength();
  
  InputStream getInputStream() throws IOException;
}


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/RequestContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */