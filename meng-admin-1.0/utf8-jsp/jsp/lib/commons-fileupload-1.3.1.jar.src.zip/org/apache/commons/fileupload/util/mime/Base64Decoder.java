/*     */ package org.apache.commons.fileupload.util.mime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Base64Decoder
/*     */ {
/*     */   private static final int INVALID_BYTE = -1;
/*     */   private static final int PAD_BYTE = -2;
/*     */   private static final int MASK_BYTE_UNSIGNED = 255;
/*     */   private static final int INPUT_BYTES_PER_CHUNK = 4;
/*     */   private static final byte[] ENCODING_TABLE = { 
/*  50 */       65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte PADDING = 61;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private static final byte[] DECODING_TABLE = new byte[256];
/*     */ 
/*     */   
/*     */   static  {
/*  78 */     for (i = 0; i < DECODING_TABLE.length; i++) {
/*  79 */       DECODING_TABLE[i] = -1;
/*     */     }
/*     */     
/*  82 */     for (i = 0; i < ENCODING_TABLE.length; i++) {
/*  83 */       DECODING_TABLE[ENCODING_TABLE[i]] = (byte)i;
/*     */     }
/*     */     
/*  86 */     DECODING_TABLE[61] = -2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int decode(byte[] data, OutputStream out) throws IOException {
/* 107 */     int outLen = 0;
/* 108 */     byte[] cache = new byte[4];
/* 109 */     int cachedBytes = 0;
/*     */     
/* 111 */     for (byte b : data) {
/* 112 */       byte d = DECODING_TABLE[0xFF & b];
/* 113 */       if (d != -1) {
/*     */ 
/*     */         
/* 116 */         cache[cachedBytes++] = d;
/* 117 */         if (cachedBytes == 4) {
/*     */           
/* 119 */           byte b1 = cache[0];
/* 120 */           byte b2 = cache[1];
/* 121 */           byte b3 = cache[2];
/* 122 */           byte b4 = cache[3];
/* 123 */           if (b1 == -2 || b2 == -2) {
/* 124 */             throw new IOException("Invalid Base64 input: incorrect padding, first two bytes cannot be padding");
/*     */           }
/*     */ 
/*     */           
/* 128 */           out.write(b1 << 2 | b2 >> 4);
/* 129 */           outLen++;
/* 130 */           if (b3 != -2) {
/*     */             
/* 132 */             out.write(b2 << 4 | b3 >> 2);
/* 133 */             outLen++;
/* 134 */             if (b4 != -2) {
/*     */               
/* 136 */               out.write(b3 << 6 | b4);
/* 137 */               outLen++;
/*     */             } 
/* 139 */           } else if (b4 != -2) {
/* 140 */             throw new IOException("Invalid Base64 input: incorrect padding, 4th byte must be padding if 3rd byte is");
/*     */           } 
/*     */           
/* 143 */           cachedBytes = 0;
/*     */         } 
/*     */       } 
/*     */     } 
/* 147 */     if (cachedBytes != 0) {
/* 148 */       throw new IOException("Invalid Base64 input: truncated");
/*     */     }
/* 150 */     return outLen;
/*     */   }
/*     */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/util/mime/Base64Decoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */