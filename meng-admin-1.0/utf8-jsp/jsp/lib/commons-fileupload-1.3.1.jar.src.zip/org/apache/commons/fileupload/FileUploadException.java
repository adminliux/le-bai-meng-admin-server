/*     */ package org.apache.commons.fileupload;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileUploadException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 8881893724388807504L;
/*     */   private final Throwable cause;
/*     */   
/*  45 */   public FileUploadException() { this(null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public FileUploadException(String msg) { this(msg, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileUploadException(String msg, Throwable cause) {
/*  66 */     super(msg);
/*  67 */     this.cause = cause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream stream) {
/*  77 */     super.printStackTrace(stream);
/*  78 */     if (this.cause != null) {
/*  79 */       stream.println("Caused by:");
/*  80 */       this.cause.printStackTrace(stream);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter writer) {
/*  92 */     super.printStackTrace(writer);
/*  93 */     if (this.cause != null) {
/*  94 */       writer.println("Caused by:");
/*  95 */       this.cause.printStackTrace(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public Throwable getCause() { return this.cause; }
/*     */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/FileUploadException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */