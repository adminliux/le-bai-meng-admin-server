package org.apache.commons.fileupload;

public interface FileItemFactory {
  FileItem createItem(String paramString1, String paramString2, boolean paramBoolean, String paramString3);
}


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/utf8-jsp/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/FileItemFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */