package org.json;

public interface JSONString {
  String toJSONString();
}


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/json.jar!/org/json/JSONString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */