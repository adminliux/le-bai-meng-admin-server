/*    */ package org.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPTokener
/*    */   extends JSONTokener
/*    */ {
/* 40 */   public HTTPTokener(String string) { super(string); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String nextToken() throws JSONException {
/*    */     char c;
/* 52 */     StringBuffer sb = new StringBuffer();
/*    */     do {
/* 54 */       c = next();
/* 55 */     } while (Character.isWhitespace(c));
/* 56 */     if (c == '"' || c == '\'') {
/* 57 */       char q = c;
/*    */       while (true) {
/* 59 */         c = next();
/* 60 */         if (c < ' ') {
/* 61 */           throw syntaxError("Unterminated string.");
/*    */         }
/* 63 */         if (c == q) {
/* 64 */           return sb.toString();
/*    */         }
/* 66 */         sb.append(c);
/*    */       } 
/*    */     } 
/*    */     while (true) {
/* 70 */       if (c == '\000' || Character.isWhitespace(c)) {
/* 71 */         return sb.toString();
/*    */       }
/* 73 */       sb.append(c);
/* 74 */       c = next();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/json.jar!/org/json/HTTPTokener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */