/*     */ package org.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONWriter
/*     */ {
/*     */   private static final int maxdepth = 200;
/*     */   private boolean comma;
/*     */   protected char mode;
/*     */   private final JSONObject[] stack;
/*     */   private int top;
/*     */   protected Writer writer;
/*     */   
/*     */   public JSONWriter(Writer w) {
/*  97 */     this.comma = false;
/*  98 */     this.mode = 'i';
/*  99 */     this.stack = new JSONObject[200];
/* 100 */     this.top = 0;
/* 101 */     this.writer = w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JSONWriter append(String string) throws JSONException {
/* 111 */     if (string == null) {
/* 112 */       throw new JSONException("Null pointer");
/*     */     }
/* 114 */     if (this.mode == 'o' || this.mode == 'a') {
/*     */       try {
/* 116 */         if (this.comma && this.mode == 'a') {
/* 117 */           this.writer.write(44);
/*     */         }
/* 119 */         this.writer.write(string);
/* 120 */       } catch (IOException e) {
/* 121 */         throw new JSONException(e);
/*     */       } 
/* 123 */       if (this.mode == 'o') {
/* 124 */         this.mode = 'k';
/*     */       }
/* 126 */       this.comma = true;
/* 127 */       return this;
/*     */     } 
/* 129 */     throw new JSONException("Value out of sequence.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONWriter array() throws JSONException {
/* 142 */     if (this.mode == 'i' || this.mode == 'o' || this.mode == 'a') {
/* 143 */       push(null);
/* 144 */       append("[");
/* 145 */       this.comma = false;
/* 146 */       return this;
/*     */     } 
/* 148 */     throw new JSONException("Misplaced array.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JSONWriter end(char mode, char c) throws JSONException {
/* 159 */     if (this.mode != mode) {
/* 160 */       throw new JSONException((mode == 'a') ? 
/* 161 */           "Misplaced endArray." : 
/* 162 */           "Misplaced endObject.");
/*     */     }
/* 164 */     pop(mode);
/*     */     try {
/* 166 */       this.writer.write(c);
/* 167 */     } catch (IOException e) {
/* 168 */       throw new JSONException(e);
/*     */     } 
/* 170 */     this.comma = true;
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   public JSONWriter endArray() throws JSONException { return end('a', ']'); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public JSONWriter endObject() throws JSONException { return end('k', '}'); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONWriter key(String string) throws JSONException {
/* 203 */     if (string == null) {
/* 204 */       throw new JSONException("Null key.");
/*     */     }
/* 206 */     if (this.mode == 'k') {
/*     */       try {
/* 208 */         this.stack[this.top - 1].putOnce(string, Boolean.TRUE);
/* 209 */         if (this.comma) {
/* 210 */           this.writer.write(44);
/*     */         }
/* 212 */         this.writer.write(JSONObject.quote(string));
/* 213 */         this.writer.write(58);
/* 214 */         this.comma = false;
/* 215 */         this.mode = 'o';
/* 216 */         return this;
/* 217 */       } catch (IOException e) {
/* 218 */         throw new JSONException(e);
/*     */       } 
/*     */     }
/* 221 */     throw new JSONException("Misplaced key.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONWriter object() throws JSONException {
/* 235 */     if (this.mode == 'i') {
/* 236 */       this.mode = 'o';
/*     */     }
/* 238 */     if (this.mode == 'o' || this.mode == 'a') {
/* 239 */       append("{");
/* 240 */       push(new JSONObject());
/* 241 */       this.comma = false;
/* 242 */       return this;
/*     */     } 
/* 244 */     throw new JSONException("Misplaced object.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pop(char c) throws JSONException {
/* 255 */     if (this.top <= 0) {
/* 256 */       throw new JSONException("Nesting error.");
/*     */     }
/* 258 */     char m = (this.stack[this.top - true] == null) ? 'a' : 'k';
/* 259 */     if (m != c) {
/* 260 */       throw new JSONException("Nesting error.");
/*     */     }
/* 262 */     this.top--;
/* 263 */     this.mode = (this.top == 0) ? 
/* 264 */       'd' : (
/* 265 */       (this.stack[this.top - true] == null) ? 
/* 266 */       'a' : 
/* 267 */       'k');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void push(JSONObject jo) throws JSONException {
/* 276 */     if (this.top >= 200) {
/* 277 */       throw new JSONException("Nesting too deep.");
/*     */     }
/* 279 */     this.stack[this.top] = jo;
/* 280 */     this.mode = (jo == null) ? 'a' : 'k';
/* 281 */     this.top++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 293 */   public JSONWriter value(boolean b) throws JSONException { return append(b ? "true" : "false"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 303 */   public JSONWriter value(double d) throws JSONException { return value(new Double(d)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   public JSONWriter value(long l) throws JSONException { return append(Long.toString(l)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 325 */   public JSONWriter value(Object object) throws JSONException { return append(JSONObject.valueToString(object)); }
/*     */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/json.jar!/org/json/JSONWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */