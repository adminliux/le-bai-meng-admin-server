/*    */ package org.json;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Iterator;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Property
/*    */ {
/*    */   public static JSONObject toJSONObject(Properties properties) throws JSONException {
/* 44 */     JSONObject jo = new JSONObject();
/* 45 */     if (properties != null && !properties.isEmpty()) {
/* 46 */       Enumeration enumProperties = properties.propertyNames();
/* 47 */       while (enumProperties.hasMoreElements()) {
/* 48 */         String name = (String)enumProperties.nextElement();
/* 49 */         jo.put(name, properties.getProperty(name));
/*    */       } 
/*    */     } 
/* 52 */     return jo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Properties toProperties(JSONObject jo) throws JSONException {
/* 63 */     Properties properties = new Properties();
/* 64 */     if (jo != null) {
/* 65 */       Iterator keys = jo.keys();
/*    */       
/* 67 */       while (keys.hasNext()) {
/* 68 */         String name = keys.next().toString();
/* 69 */         properties.put(name, jo.getString(name));
/*    */       } 
/*    */     } 
/* 72 */     return properties;
/*    */   }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/json.jar!/org/json/Property.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */