package org.apache.commons.fileupload;

public interface FileItemHeadersSupport {
  FileItemHeaders getHeaders();
  
  void setHeaders(FileItemHeaders paramFileItemHeaders);
}


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/FileItemHeadersSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */