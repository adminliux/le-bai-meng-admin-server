/*    */ package org.apache.commons.fileupload.util.mime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 5355281266579392077L;
/*    */   
/* 35 */   public ParseException(String message) { super(message); }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/util/mime/ParseException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */