/*     */ package org.apache.commons.fileupload.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.fileupload.InvalidFileNameException;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Streams
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   
/*  70 */   public static long copy(InputStream inputStream, OutputStream outputStream, boolean closeOutputStream) throws IOException { return copy(inputStream, outputStream, closeOutputStream, new byte[8192]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long copy(InputStream inputStream, OutputStream outputStream, boolean closeOutputStream, byte[] buffer) throws IOException {
/*  95 */     out = outputStream;
/*  96 */     in = inputStream;
/*     */     try {
/*  98 */       long total = 0L;
/*     */       while (true) {
/* 100 */         int res = in.read(buffer);
/* 101 */         if (res == -1) {
/*     */           break;
/*     */         }
/* 104 */         if (res > 0) {
/* 105 */           total += res;
/* 106 */           if (out != null) {
/* 107 */             out.write(buffer, 0, res);
/*     */           }
/*     */         } 
/*     */       } 
/* 111 */       if (out != null) {
/* 112 */         if (closeOutputStream) {
/* 113 */           out.close();
/*     */         } else {
/* 115 */           out.flush();
/*     */         } 
/* 117 */         out = null;
/*     */       } 
/* 119 */       in.close();
/* 120 */       in = null;
/* 121 */       return total;
/*     */     } finally {
/* 123 */       IOUtils.closeQuietly(in);
/* 124 */       if (closeOutputStream) {
/* 125 */         IOUtils.closeQuietly(out);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String asString(InputStream inputStream) throws IOException {
/* 142 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 143 */     copy(inputStream, baos, true);
/* 144 */     return baos.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String asString(InputStream inputStream, String encoding) throws IOException {
/* 159 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 160 */     copy(inputStream, baos, true);
/* 161 */     return baos.toString(encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String checkFileName(String fileName) {
/* 175 */     if (fileName != null && fileName.indexOf(false) != -1) {
/*     */       
/* 177 */       StringBuilder sb = new StringBuilder();
/* 178 */       for (int i = 0; i < fileName.length(); i++) {
/* 179 */         char c = fileName.charAt(i);
/* 180 */         switch (c) {
/*     */           case '\000':
/* 182 */             sb.append("\\0");
/*     */             break;
/*     */           default:
/* 185 */             sb.append(c);
/*     */             break;
/*     */         } 
/*     */       } 
/* 189 */       throw new InvalidFileNameException(fileName, "Invalid file name: " + sb);
/*     */     } 
/*     */     
/* 192 */     return fileName;
/*     */   }
/*     */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/util/Streams.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */