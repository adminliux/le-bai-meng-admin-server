/*     */ package org.apache.commons.fileupload.disk;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileItemHeaders;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.ParameterParser;
/*     */ import org.apache.commons.fileupload.util.Streams;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.io.output.DeferredFileOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiskFileItem
/*     */   implements FileItem
/*     */ {
/*     */   private static final long serialVersionUID = 2237570099615271025L;
/*     */   public static final String DEFAULT_CHARSET = "ISO-8859-1";
/*  99 */   private static final String UID = UUID.randomUUID().toString().replace('-', '_');
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static final AtomicInteger COUNTER = new AtomicInteger(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fieldName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String contentType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFormField;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String fileName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   private long size = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int sizeThreshold;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final File repository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] cachedContent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DeferredFileOutputStream dfos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File tempFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File dfosFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FileItemHeaders headers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiskFileItem(String fieldName, String contentType, boolean isFormField, String fileName, int sizeThreshold, File repository) {
/* 192 */     this.fieldName = fieldName;
/* 193 */     this.contentType = contentType;
/* 194 */     this.isFormField = isFormField;
/* 195 */     this.fileName = fileName;
/* 196 */     this.sizeThreshold = sizeThreshold;
/* 197 */     this.repository = repository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 213 */     if (!isInMemory()) {
/* 214 */       return new FileInputStream(this.dfos.getFile());
/*     */     }
/*     */     
/* 217 */     if (this.cachedContent == null) {
/* 218 */       this.cachedContent = this.dfos.getData();
/*     */     }
/* 220 */     return new ByteArrayInputStream(this.cachedContent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public String getContentType() { return this.contentType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharSet() {
/* 242 */     ParameterParser parser = new ParameterParser();
/* 243 */     parser.setLowerCaseNames(true);
/*     */     
/* 245 */     Map<String, String> params = parser.parse(getContentType(), ';');
/* 246 */     return (String)params.get("charset");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 259 */   public String getName() { return Streams.checkFileName(this.fileName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInMemory() {
/* 272 */     if (this.cachedContent != null) {
/* 273 */       return true;
/*     */     }
/* 275 */     return this.dfos.isInMemory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSize() {
/* 284 */     if (this.size >= 0L)
/* 285 */       return this.size; 
/* 286 */     if (this.cachedContent != null)
/* 287 */       return this.cachedContent.length; 
/* 288 */     if (this.dfos.isInMemory()) {
/* 289 */       return this.dfos.getData().length;
/*     */     }
/* 291 */     return this.dfos.getFile().length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] get() {
/* 303 */     if (isInMemory()) {
/* 304 */       if (this.cachedContent == null) {
/* 305 */         this.cachedContent = this.dfos.getData();
/*     */       }
/* 307 */       return this.cachedContent;
/*     */     } 
/*     */     
/* 310 */     byte[] fileData = new byte[(int)getSize()];
/* 311 */     fis = null;
/*     */     
/*     */     try {
/* 314 */       fis = new BufferedInputStream(new FileInputStream(this.dfos.getFile()));
/* 315 */       fis.read(fileData);
/* 316 */     } catch (IOException e) {
/* 317 */       fileData = null;
/*     */     } finally {
/* 319 */       if (fis != null) {
/*     */         try {
/* 321 */           fis.close();
/* 322 */         } catch (IOException e) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 328 */     return fileData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 345 */   public String getString(String charset) throws UnsupportedEncodingException { return new String(get(), charset); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString() {
/* 358 */     byte[] rawdata = get();
/* 359 */     String charset = getCharSet();
/* 360 */     if (charset == null) {
/* 361 */       charset = "ISO-8859-1";
/*     */     }
/*     */     try {
/* 364 */       return new String(rawdata, charset);
/* 365 */     } catch (UnsupportedEncodingException e) {
/* 366 */       return new String(rawdata);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File file) throws Exception {
/* 391 */     if (isInMemory()) {
/* 392 */       fout = null;
/*     */       try {
/* 394 */         fout = new FileOutputStream(file);
/* 395 */         fout.write(get());
/*     */       } finally {
/* 397 */         if (fout != null) {
/* 398 */           fout.close();
/*     */         }
/*     */       } 
/*     */     } else {
/* 402 */       File outputFile = getStoreLocation();
/* 403 */       if (outputFile != null) {
/*     */         
/* 405 */         this.size = outputFile.length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 411 */         if (!outputFile.renameTo(file)) {
/* 412 */           in = null;
/* 413 */           out = null;
/*     */           try {
/* 415 */             in = new BufferedInputStream(new FileInputStream(outputFile));
/*     */             
/* 417 */             out = new BufferedOutputStream(new FileOutputStream(file));
/*     */             
/* 419 */             IOUtils.copy(in, out);
/*     */           } finally {
/* 421 */             if (in != null) {
/*     */               try {
/* 423 */                 in.close();
/* 424 */               } catch (IOException e) {}
/*     */             }
/*     */ 
/*     */             
/* 428 */             if (out != null) {
/*     */               try {
/* 430 */                 out.close();
/* 431 */               } catch (IOException e) {}
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 442 */         throw new FileUploadException("Cannot write uploaded file to disk!");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() {
/* 456 */     this.cachedContent = null;
/* 457 */     File outputFile = getStoreLocation();
/* 458 */     if (outputFile != null && outputFile.exists()) {
/* 459 */       outputFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 473 */   public String getFieldName() { return this.fieldName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 485 */   public void setFieldName(String fieldName) { this.fieldName = fieldName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 499 */   public boolean isFormField() { return this.isFormField; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 513 */   public void setFormField(boolean state) { this.isFormField = state; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 527 */     if (this.dfos == null) {
/* 528 */       File outputFile = getTempFile();
/* 529 */       this.dfos = new DeferredFileOutputStream(this.sizeThreshold, outputFile);
/*     */     } 
/* 531 */     return this.dfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getStoreLocation() {
/* 550 */     if (this.dfos == null) {
/* 551 */       return null;
/*     */     }
/* 553 */     return this.dfos.getFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() {
/* 563 */     File outputFile = this.dfos.getFile();
/*     */     
/* 565 */     if (outputFile != null && outputFile.exists()) {
/* 566 */       outputFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getTempFile() {
/* 579 */     if (this.tempFile == null) {
/* 580 */       File tempDir = this.repository;
/* 581 */       if (tempDir == null) {
/* 582 */         tempDir = new File(System.getProperty("java.io.tmpdir"));
/*     */       }
/*     */       
/* 585 */       String tempFileName = String.format("upload_%s_%s.tmp", new Object[] { UID, getUniqueId() });
/*     */       
/* 587 */       this.tempFile = new File(tempDir, tempFileName);
/*     */     } 
/* 589 */     return this.tempFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getUniqueId() {
/* 601 */     limit = 100000000;
/* 602 */     int current = COUNTER.getAndIncrement();
/* 603 */     String id = Integer.toString(current);
/*     */ 
/*     */ 
/*     */     
/* 607 */     if (current < 100000000) {
/* 608 */       id = ("00000000" + id).substring(id.length());
/*     */     }
/* 610 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 620 */   public String toString() { return String.format("name=%s, StoreLocation=%s, size=%s bytes, isFormField=%s, FieldName=%s", new Object[] { getName(), getStoreLocation(), Long.valueOf(getSize()), Boolean.valueOf(isFormField()), getFieldName() }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 636 */     if (this.dfos.isInMemory()) {
/* 637 */       this.cachedContent = get();
/*     */     } else {
/* 639 */       this.cachedContent = null;
/* 640 */       this.dfosFile = this.dfos.getFile();
/*     */     } 
/*     */ 
/*     */     
/* 644 */     out.defaultWriteObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 658 */     in.defaultReadObject();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 665 */     if (this.repository != null) {
/* 666 */       if (this.repository.isDirectory()) {
/*     */         
/* 668 */         if (this.repository.getPath().contains("\000")) {
/* 669 */           throw new IOException(String.format("The repository [%s] contains a null character", new Object[] { this.repository.getPath() }));
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 674 */         throw new IOException(String.format("The repository [%s] is not a directory", new Object[] { this.repository.getAbsolutePath() }));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 680 */     OutputStream output = getOutputStream();
/* 681 */     if (this.cachedContent != null) {
/* 682 */       output.write(this.cachedContent);
/*     */     } else {
/* 684 */       FileInputStream input = new FileInputStream(this.dfosFile);
/* 685 */       IOUtils.copy(input, output);
/* 686 */       this.dfosFile.delete();
/* 687 */       this.dfosFile = null;
/*     */     } 
/* 689 */     output.close();
/*     */     
/* 691 */     this.cachedContent = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 699 */   public FileItemHeaders getHeaders() { return this.headers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 707 */   public void setHeaders(FileItemHeaders pHeaders) { this.headers = pHeaders; }
/*     */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/disk/DiskFileItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */