/*    */ package org.apache.commons.fileupload.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.fileupload.FileItemHeaders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileItemHeadersImpl
/*    */   implements FileItemHeaders, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4455695752627032559L;
/* 48 */   private final Map<String, List<String>> headerNameToValueListMap = new LinkedHashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getHeader(String name) {
/* 54 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 55 */     List<String> headerValueList = (List)this.headerNameToValueListMap.get(nameLower);
/* 56 */     if (null == headerValueList) {
/* 57 */       return null;
/*    */     }
/* 59 */     return (String)headerValueList.get(0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   public Iterator<String> getHeaderNames() { return this.headerNameToValueListMap.keySet().iterator(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<String> getHeaders(String name) {
/* 73 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 74 */     List<String> headerValueList = (List)this.headerNameToValueListMap.get(nameLower);
/* 75 */     if (null == headerValueList) {
/* 76 */       headerValueList = Collections.emptyList();
/*    */     }
/* 78 */     return headerValueList.iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addHeader(String name, String value) {
/* 88 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 89 */     List<String> headerValueList = (List)this.headerNameToValueListMap.get(nameLower);
/* 90 */     if (null == headerValueList) {
/* 91 */       headerValueList = new ArrayList<String>();
/* 92 */       this.headerNameToValueListMap.put(nameLower, headerValueList);
/*    */     } 
/* 94 */     headerValueList.add(value);
/*    */   }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/commons-fileupload-1.3.1.jar!/org/apache/commons/fileupload/util/FileItemHeadersImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.2
 */