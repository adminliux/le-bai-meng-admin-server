package com.baidu.ueditor.define;

public interface State {
  boolean isSuccess();
  
  void putInfo(String paramString1, String paramString2);
  
  void putInfo(String paramString, long paramLong);
  
  String toJSONString();
}


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/ueditor-1.1.2.jar!/com/baidu/ueditor/define/State.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */