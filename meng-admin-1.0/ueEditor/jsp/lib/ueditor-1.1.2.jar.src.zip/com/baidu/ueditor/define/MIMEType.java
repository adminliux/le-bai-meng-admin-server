/*    */ package com.baidu.ueditor.define;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MIMEType
/*    */ {
/*  8 */   public static final Map<String, String> types = new HashMap<String, String>()
/*    */     {
/*    */     
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 17 */   public static String getSuffix(String mime) { return (String)types.get(mime); }
/*    */ }


/* Location:              /Volumes/backs/le-mai-meng-api-server/meng-api-1.0/WEB-INF/lib/common-module-1.0.jar!/common-static/ueEditor/jsp/lib/ueditor-1.1.2.jar!/com/baidu/ueditor/define/MIMEType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.2
 */